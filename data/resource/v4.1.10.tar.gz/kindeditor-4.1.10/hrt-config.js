
exports.map = [
  ['http://text.agw8.com/kindeditor/kindeditor.js', 'D:\\project\\kindeditor\\kindeditor-all.js'],
];
